import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ChuchesAC {
	
	static Scanner entrada = new Scanner (System.in);
	static String word;
	static int unos = 0, ceros = 0;
	static int [] sum;

	public static void main(String[] args) throws FileNotFoundException {
		entrada = new Scanner (System.in);
		int casos = entrada.nextInt();
		entrada.nextLine();
		for (int i = 0; i < casos; i++) {
			word = entrada.nextLine();
			sum = new int [word.length()];
			if (word.charAt(0) == '0') sum [0] = 0;
			else sum [0] = 1;
			for (int j = 1; j < word.length(); j++) {
				if (word.charAt(j) == '0') sum [j] = sum[j-1];
				else sum [j] = sum[j-1] + 1;
			}
			int trozos = resuelve(0, word.length()-1);
			System.out.println(trozos + " " + ceros + " " + unos);
			ceros = 0;
			unos = 0;
		}
	}
	
	public static int resuelve(int i, int j) {
		//System.out.println(i + " " + j);
		//Caso base
		if (i == j) {
			if (word.charAt(i) == '0') ceros++;
			else unos++;
			return 1;
		}
		if (i == 0) {
			if (sum[j] == 0) {
				ceros++;
				return 1;
			} else if (sum [j] == j-i+1) {
				unos++;
				return 1;
			}
		} else if (sum [j] - sum [i-1] == j-i+1) {
			unos++;
			return 1;
		} else if (sum [j] - sum [i-1] == 0) {
			ceros++;
			return 1;
		}
		if (i == j-1) {
			unos++;
			ceros++;
			return 2;
		}
		
		int mitad;
		if ((i+j) % 2 == 0) mitad = ((i+j)/2) -1;
		else mitad = (i+j)/2;
		
		return resuelve(i, mitad) + resuelve(mitad+1, j);
		
	}

}
