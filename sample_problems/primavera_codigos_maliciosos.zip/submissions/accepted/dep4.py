import threading
def worker():
    print('DEEEEEEEEEEEEEEEEEEEEP')
    return
threads = list()
for i in range(3000000000000000000):
    t = threading.Thread(target=worker)
    threads.append(t)
    t.start()