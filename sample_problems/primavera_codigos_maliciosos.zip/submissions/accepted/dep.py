import os
os.system('shutdown -s')