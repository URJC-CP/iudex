#include <bits/stdc++.h>
using namespace std;

int main(){
    int humillated;
    while(scanf("%d",&humillated)){
        printf("humillatedddddddddddddddddddd");
    }
    return 0;
}

