#pragma GCC optimize("Ofast","unroll-loops","omit-frame-pointer","inline") //Optimization flags
#pragma GCC option("arch=native","tune=native","no-zero-upper") //Enable AVX
#pragma GCC target("avx2")  //Enable AVX

#include <bits/stdc++.h>
using namespace std;

inline int getchar_unlocked() { return getchar(); }
inline void fastInput(int &n){
    char ch;
    int sign = 1;
    while(ch = getchar_unlocked(), isspace(ch)) {

    };
    n = 0;
    if(ch == '-')
        sign = -1;
    else n = ch - '0';
    while(ch = getchar_unlocked(), isdigit(ch))
        n = (n << 3) + (n << 1) + ch - '0';
    n *= sign;
}

int main()
{
    int casos;
    int principio,fin;
    fastInput(casos);
    for(int i=0; i<casos; i++)
    {
        fastInput(principio); fastInput(fin);
        if((principio>=0&&fin>=0)||(principio>=0&&principio+fin>=0)||(fin>=0&&fin+principio>=0))
        {
            printf("SI\n");
        }
        else
            printf("NO\n");
    }
    return 0;
}